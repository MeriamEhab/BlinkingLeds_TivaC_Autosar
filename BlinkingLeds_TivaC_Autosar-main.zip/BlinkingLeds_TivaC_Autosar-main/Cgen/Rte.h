#ifndef RTE_H_
#define RTE_H_


#include "Rte_Type.h"




#ifdef RTE_APPLICATION_SWC_1_H_
Std_ReturnType Rte_Write_Component_Composition_SWC1_P_SR_State_1_Element_1(State data);

#endif


#ifdef RTE_APPLICATION_SWC_2_H_
Std_ReturnType Rte_IRead_State_1_Element_1_Component_Composition_SWC2_R_SR_Application_SWC_2_Runnable_1 (State* data);

#endif


#ifdef RTE_CDD_H_

#endif





#endif
