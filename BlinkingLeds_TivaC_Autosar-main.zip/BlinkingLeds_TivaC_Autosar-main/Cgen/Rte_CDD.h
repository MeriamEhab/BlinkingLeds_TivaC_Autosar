#ifndef RTE_CDD_H_
#define RTE_CDD_H_


#include "Rte.h"


typedef enum{
    RED = 1,BLUE,GREEN
}leds_num;

leds_num CS_Clear_Argument_1;
leds_num CS_Set_Argument_1;




#endif
